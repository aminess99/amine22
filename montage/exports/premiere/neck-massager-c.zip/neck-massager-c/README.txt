Premiere Pro: File > Import > neck-massager-c.xml
If Premiere asks to locate media: click Locate, open the media folder next to the XML,
pick the file it asks for, and Premiere links the rest.
V1 shots + end card | V2 karaoke captions (PNG) | A1 voice | A2 music | A3+ sound effects.
captions.srt: plain captions (File > Import) if you prefer Premiere's own caption styling.
